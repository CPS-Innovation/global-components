We will build a browser extension for MS Edge. To begin with it will allow us to specify a certain page URL root and allow us to hide the `header` element whenever the user is on that page
