declare global {
    interface Window {
        cps_global_components_cookie_handover_url: string;
        cps_global_components_token_handover_url: string;
    }
}
export {};
//# sourceMappingURL=auth-handover.d.ts.map