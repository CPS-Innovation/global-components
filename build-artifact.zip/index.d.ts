export { createOutboundUrl } from "./handover";
//# sourceMappingURL=index.d.ts.map