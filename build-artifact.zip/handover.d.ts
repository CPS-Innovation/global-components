export declare const createOutboundUrl: ({ handoverUrl, targetUrl, }: {
    handoverUrl: string;
    targetUrl: string;
}) => string;
export declare const handleRedirect: ({ currentUrl, cookieHandoverUrl, tokenHandoverUrl, }: {
    currentUrl: string;
    cookieHandoverUrl: string;
    tokenHandoverUrl: string;
}) => string;
//# sourceMappingURL=handover.d.ts.map